#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Imu
import serial
import time

def request_imu(stm32):
    try:
        stm32.write(bytearray([0x03]))  # Send request
        time.sleep(0.5)
        return stm32.readline().decode("utf-8")
    except serial.SerialException as e:
        rospy.logerr("Error reading from serial port: {}".format(e))
        return None

def imu_publisher():
    rospy.init_node('imu_publisher_node', anonymous=True)
    imu_pub = rospy.Publisher('imu/data', Imu, queue_size=10)
    rate = rospy.Rate(2)  # 2 Hz

    port_name = "/dev/ttyACM0"
    try:
        stm32 = serial.Serial(port_name, 9600, timeout=1)
    except serial.SerialException as e:
        rospy.logfatal("Error opening serial port: {}".format(e))
        exit(1)

    while not rospy.is_shutdown():
        raw_data = request_imu(stm32)
        if raw_data:
            data = raw_data.lstrip('\x00').rstrip('\r\n')
            data_list = data.split(',')

            if len(data_list) >= 6:
                try:
                    imu_msg = Imu()
                    imu_msg.header.stamp = rospy.Time.now()
                    imu_msg.header.frame_id = "imu_link"
                    imu_msg.linear_acceleration.x = float(data_list[0])
                    imu_msg.linear_acceleration.y = float(data_list[1])
                    imu_msg.linear_acceleration.z = float(data_list[2])
                    imu_msg.angular_velocity.x = float(data_list[3])
                    imu_msg.angular_velocity.y = float(data_list[4])
                    imu_msg.angular_velocity.z = float(data_list[5])
                    imu_pub.publish(imu_msg)
                except ValueError as e:
                    rospy.logwarn("Error converting data to float: {}".format(e))
            else:
                rospy.logwarn("Incomplete data received.")
        else:
            rospy.logwarn("Failed to read data from STM32.")

        rate.sleep()

if __name__ == '__main__':
    try:
        imu_publisher()
    except rospy.ROSInterruptException:
        pass
