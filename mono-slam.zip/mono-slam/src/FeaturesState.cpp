/*
 * FeaturesState.cpp
 *
 *  Created on: Jul 22, 2013
 *      Author: ludovicorusso
 */

#include "FeaturesState.h"

FeaturesState::FeaturesState() {
	// TODO Auto-generated constructor stub

}

FeaturesState::~FeaturesState() {
	// TODO Auto-generated destructor stub
}
